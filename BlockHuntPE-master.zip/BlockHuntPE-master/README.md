# BlockHuntPE
A Hide and Seek plugin for ImagicalMine
